# Debloat Script
Write-Output 'Running debloat...'