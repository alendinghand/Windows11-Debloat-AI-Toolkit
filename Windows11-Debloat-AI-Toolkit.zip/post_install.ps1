# Post-install Extras
Write-Output 'Installing Sysinternals, PowerToys...'